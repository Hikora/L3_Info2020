package Exercice6EntNat;

public class ErrModif extends Exception {

	private static final long serialVersionUID = 1L;

}
