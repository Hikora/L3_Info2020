package Exercice1;

public class Exc3 extends Exception{

}
