package Exercice1;

public class Exc321 extends Exc32{

}
