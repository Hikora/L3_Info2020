package Exercice1;

public class Exc32 extends Exc3{

}
