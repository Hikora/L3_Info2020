package Exercice1;

import java.io.IOException;

public class Exc2 extends  IOException{

}
