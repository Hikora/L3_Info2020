package Exercice1;

public class Exc31 extends Exc3{

}
