package Exercice1;



public class Exc1 extends  RuntimeException { } 


