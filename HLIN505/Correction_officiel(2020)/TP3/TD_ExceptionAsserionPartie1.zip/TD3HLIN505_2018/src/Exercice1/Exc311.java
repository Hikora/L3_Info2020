package Exercice1;

public class Exc311 extends Exc31{

}
