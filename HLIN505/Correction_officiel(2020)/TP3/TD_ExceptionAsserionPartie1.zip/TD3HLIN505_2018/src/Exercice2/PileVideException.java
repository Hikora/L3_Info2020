package Exercice2;

public class PileVideException extends Exception {

}
