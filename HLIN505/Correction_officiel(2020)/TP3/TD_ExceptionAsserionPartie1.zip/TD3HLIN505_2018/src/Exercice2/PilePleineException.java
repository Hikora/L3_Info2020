package Exercice2;

public class PilePleineException extends Exception {

}
