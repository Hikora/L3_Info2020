package Exercice6EntNatPartie2;

public class ErrModif extends ErrNat {

	private static final long serialVersionUID = 1L;

	public ErrModif(int nb) {
		super(nb);
	}
	
}
