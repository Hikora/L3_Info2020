package Exercice6EntNatPartie2;
public class ErrConst extends ErrNat {

	private static final long serialVersionUID = 1L;

	public ErrConst(int nb) {
		super(nb);
	}
	
}

