package Exo2;

public abstract class Operande {
	public abstract float eval();
}
