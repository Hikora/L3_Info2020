package Exercice1_JUnit;

public class FooBarException extends Exception {

}