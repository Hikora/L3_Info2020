package Exercice2_JUnit;

public enum NatureEtape {
musee,
visiteMonument,
visiteJardin,
lieuInteretSansVisite;
}
