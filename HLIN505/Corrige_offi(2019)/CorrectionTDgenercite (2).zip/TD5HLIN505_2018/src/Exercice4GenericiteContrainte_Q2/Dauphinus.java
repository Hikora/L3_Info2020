package Exercice4GenericiteContrainte_Q2;

public interface Dauphinus {

}
