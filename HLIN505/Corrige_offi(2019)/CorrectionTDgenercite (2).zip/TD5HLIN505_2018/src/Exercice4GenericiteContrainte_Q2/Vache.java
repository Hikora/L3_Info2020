package Exercice4GenericiteContrainte_Q2;

public class Vache implements Taurus {
	public String toString() { return "Vache"; }
}