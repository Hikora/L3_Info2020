package Exercice4GenericiteContrainte_Q2;

public class CoupleEspece<E,A extends E,B extends E> extends Paire<A,B> {
	public CoupleEspece(A a, B b) {
		super(a,b);
	}
	
	public static void main(String[] args) {
		CoupleEspece<Taurus,Taureau,Vache> ce2 = new CoupleEspece<Taurus,Taureau,Vache>(new Taureau(),new Vache());
		System.out.println(ce2);
		CoupleEspece<Dauphinus,Dauphin,Dauphin> ce1 = new CoupleEspece<Dauphinus,Dauphin,Dauphin>(new Dauphin(),new Dauphin());
		System.out.println(ce1);		
	}
}
