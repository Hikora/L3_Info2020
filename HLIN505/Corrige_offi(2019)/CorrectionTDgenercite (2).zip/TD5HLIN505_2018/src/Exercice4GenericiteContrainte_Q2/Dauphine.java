package Exercice4GenericiteContrainte_Q2;

public class Dauphine implements Dauphinus {
	public String toString() { return "Dauphine"; }
}

