package Exercice4GenericiteContrainte_Q2;

public class Taureau implements Taurus {
	public String toString() { return "Taureau"; }
}

