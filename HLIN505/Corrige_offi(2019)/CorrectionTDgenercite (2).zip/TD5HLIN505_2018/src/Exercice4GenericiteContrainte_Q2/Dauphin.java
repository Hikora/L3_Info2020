package Exercice4GenericiteContrainte_Q2;

public class Dauphin implements Dauphinus {
	public String toString() { return "Dauphin"; }
}

