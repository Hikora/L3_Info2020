package Exercice3FilePriorite;

public interface ElementAvecPriorite {
	int priorite();
}
