package Exercice4GenericiteContrainte;

public class Vache implements Femelle {
	public String toString() { return "Vache"; }
}
