package Exercice4GenericiteContrainte;

public class Dauphine implements Femelle {
	public String toString() { return "Dauphine"; }
}
