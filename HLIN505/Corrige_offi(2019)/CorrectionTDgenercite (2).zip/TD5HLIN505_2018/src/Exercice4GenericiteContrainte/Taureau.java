package Exercice4GenericiteContrainte;

public class Taureau implements Male {
	public String toString() { return "Taureau"; }
}

