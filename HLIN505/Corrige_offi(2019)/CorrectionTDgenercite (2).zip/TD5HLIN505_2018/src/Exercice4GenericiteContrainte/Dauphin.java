package Exercice4GenericiteContrainte;

public class Dauphin implements Male {
	public String toString() { return "Dauphin"; }
}

