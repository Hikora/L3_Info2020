package Exercice4GenericiteContrainte;

import java.util.*;
public class Paire<A,B> {
	public A first;
	public B second;
	
	public Paire() {		
	}
	
	public Paire(A f, B s) {
		first = f;
		second = s;
	}
	
	public String toString() {
		return "("+first + " , "+second+")";
	}
	
	public <C> boolean memeFst(Paire<A,C> p) 
    {return first==p.first;}
	
	void printCollection(Collection<?> c) 
	{ 
	for (Object e : c) 
	{ 
	System.out.println(e); 
	}}
	
	public static void main(String[] args) {
		Paire<String, Integer> paire = new Paire<String,Integer>("toto",2);		
		
		System.out.println(paire);		
		System.out.println(paire.memeFst(new Paire<String,Integer>("toto",3)));
	}
}
