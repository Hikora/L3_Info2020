package Exercice4GenericiteContrainte;

public class CoupleConventionnel<A extends Male, B extends Femelle> extends Paire<A, B> {
	public CoupleConventionnel(A a, B b) {
		super(a,b);		
	}
	
	public static void main(String[] args) {
		// Question 1 :
		CoupleConventionnel<Taureau,Vache> cc1 = new CoupleConventionnel<Taureau,Vache>(new Taureau(),new Vache());
		System.out.println(cc1);
		CoupleConventionnel<Taureau,Dauphine> cc2 = new CoupleConventionnel<Taureau,Dauphine>(new Taureau(),new Dauphine());
		System.out.println(cc2);
		
		// Question 2 :
		
	}
}

