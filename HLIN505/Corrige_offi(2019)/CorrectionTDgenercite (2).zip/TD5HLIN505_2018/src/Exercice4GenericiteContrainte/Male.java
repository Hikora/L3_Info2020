package Exercice4GenericiteContrainte;

public interface Male {

}
