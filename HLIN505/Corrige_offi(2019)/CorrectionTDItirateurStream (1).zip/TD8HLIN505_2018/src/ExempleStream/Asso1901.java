package ExempleStream;

import java.util.*;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

// ---- Iterateurs ----
//
// Problème : on dispose d'une collection de données ou d'une structure composite (agrégat)
// et on souhaite la naviguer 
// - visiter les éléments internes un par un, peut-être pas d'une seule traite
// - par une interface uniforme
// - sans connaître les détails de la structure interne
// - en cas d'évolution de la structure interne, le programme utilisateur (client)
//   ne sera pas modifié.
// - l'itération est externe (gérée par un objet extérieur

// On indique que la classe en question est Iterable
// le paramètre de généricité est le type des éléments qui seront retournés

public class Asso1901 implements Iterable<MembreAsso>{
	private String siegeSocial;
	private MembreAsso president;
	private ArrayList<MembreAsso> adherents = new ArrayList<>(), 
			                  membresHonoraires = new ArrayList<>();
	@Override
	public Iterator<MembreAsso> iterator() {
		return new IteratorAsso1901(this);
	}
	public Asso1901(String siegeSocial) {
		this.siegeSocial = siegeSocial;
	}
	public void inscritAdherent(MembreAsso m) {		
		this.adherents.add(m);
	}
	public void inscritHonoraire(MembreAsso m) {
		this.membresHonoraires.add(m);
	}
	public String getSiegeSocial() {
		return siegeSocial;
	}
	public void setSiegeSocial(String siegeSocial) {
		this.siegeSocial = siegeSocial;
	}
	public MembreAsso getPresident() {
		return president;
	}
	public void setPresident(MembreAsso president) {
		this.president = president;
	}
	public ArrayList<MembreAsso> getAdherents() {
		return adherents;
	}
	public void setAdherents(ArrayList<MembreAsso> adherents) {
		this.adherents = adherents;
	}
	@Override
	public String toString() {
		return "AssociationLoi1901 [siegeSocial=" + siegeSocial + " adherents=" + adherents + "]";
	}
	
	public static void main(String[] args) {
		
		// Itération sur une ArrayList
		
		ArrayList<String> texte = new ArrayList<String>();
		texte.add("le");
		texte.add("matin");
		Iterator<String> ite = texte.iterator();
		String res = "1-";
		while (ite.hasNext())
			res += ite.next()+" ";
		System.out.println(res);	
		res = "2-";
		for (String s:texte)
			res += s +" ";
		System.out.println(res);		
		
		// Itération sur une association

		Asso1901 assoc = new Asso1901("Paris");
		assoc.setPresident(new MembreAsso("Sara","Pierre",true));
		assoc.inscritAdherent(new MembreAsso("Jeanne","Marc",true));
		assoc.inscritAdherent(new MembreAsso("Marie","Deschamps",true));
		System.out.println(assoc);
		System.out.println("---");	
		
		// on parcourt les membres de l'association 
		// comme s'il s'agissait d'une liste
		// alors qu'ils sont dans un attribut et dans une liste
		
		for (MembreAsso m : assoc)
			System.out.println("membre asso 1901 :  "+m.getNom());	
		
		// Et maintenant on regarde quelques exemples d'utilisation des streams
		
		System.out.println("--- Adherents ayant paye leur cotisation ----");	
		
		assoc.getAdherents()
			.stream()
			.filter(m -> m.isCotisationAjour())
			.map(m -> m.getNom())
			.forEach(S -> System.out.println(S));
		
		System.out.println(assoc.getAdherents()
							.stream()
							.mapToDouble(m -> m.getAge())
							.average());			

		System.out.println("--- Adherents majeurs ----");	
		
		Stream<MembreAsso> majeurs =
				assoc.getAdherents()
				.stream()
				.filter(m -> m.isCotisationAjour());
		
		majeurs.forEach(m->System.out.println(m));
		
		System.out.println("--- Membres ayant paye leur cotisation ----");	
		
		// on doit transformer l'iterable en stream
		
		StreamSupport.stream(assoc.spliterator(), false)
			.filter(m -> m.isCotisationAjour())
			.map(MembreAsso::getNom)
			.forEach(S -> System.out.println(S));

	}
}


// L'itérateur implémente les méthodes next, hasNext qui servent 
// à parcourir d'une manière transparente tous les membres de l'association
// même si certains sont dans des valeurs d'attributs et les autres dans deux listes

class IteratorAsso1901 implements Iterator<MembreAsso> {
	
	private Asso1901 assocParcourue;
	private int curseur; // valeur utile quand on doit retourner des adhérents
	private boolean pdt; // vrai quand on doit retourner le président

	public IteratorAsso1901(Asso1901 assoc) {
		this.assocParcourue=assoc;
		curseur = 0; pdt = true;
	}

	@Override
	public boolean hasNext() {
		return (pdt || curseur<this.assocParcourue.getAdherents().size());
	}

	@Override
	public MembreAsso next() {
		if (pdt)
			{
				pdt = false;
				return this.assocParcourue.getPresident();
			}
		else
			if (curseur<this.assocParcourue.getAdherents().size())
				{
					MembreAsso m = this.assocParcourue.getAdherents().get(curseur);
					curseur++;
					return m;
				}
		return null;
	}
}

class MembreAsso{
	private String nom="inconnu", prenom="inconnu";
	private boolean cotisationAjour;
	private int age=18;
	
	public MembreAsso(String nom, String prenom, boolean cotisationAjour) {
		this.nom = nom;
		this.prenom = prenom;
		this.cotisationAjour = cotisationAjour;
	}

	public String getNom() {return nom;}
	public void setNom(String nom) {this.nom = nom;}

	public String getPrenom() {return prenom;}
	public void setPrenom(String prenom) {this.prenom = prenom;}

	public boolean isCotisationAjour() {return cotisationAjour;}
	public void setCotisationAjour(boolean cotisationAjour) {this.cotisationAjour = cotisationAjour;}

	public int getAge() {return age;}
	public void setAge(int age) {this.age = age;}

	@Override
	public String toString() {
		return "Membre [nom=" + nom + ", prenom=" + prenom + ", cotisationAjour=" + cotisationAjour + ", age="+age+"]";
	}	
}

