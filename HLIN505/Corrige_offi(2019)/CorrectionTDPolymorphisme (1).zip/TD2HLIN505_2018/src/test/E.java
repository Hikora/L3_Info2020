package test;

public class E extends Y{

}
