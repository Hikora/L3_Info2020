package test;

public class Z extends Y{

}
