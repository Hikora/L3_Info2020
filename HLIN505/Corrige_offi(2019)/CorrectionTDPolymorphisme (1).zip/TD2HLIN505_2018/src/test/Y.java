package test;

public class Y extends X{

}
