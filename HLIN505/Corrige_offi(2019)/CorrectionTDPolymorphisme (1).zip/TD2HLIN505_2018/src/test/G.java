package test;

public class G extends F{

}
