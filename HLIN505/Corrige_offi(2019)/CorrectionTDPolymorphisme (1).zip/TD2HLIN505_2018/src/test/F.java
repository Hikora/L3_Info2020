package test;

public class F extends E{

}
