
import java.util.*;
import java.io.File;
import java.lang.reflect.*;

import javax.swing.*;

@SuppressWarnings({"unchecked","rawtypes","unused"})
public class Exo1 {	
	static ArrayList list;
	static ArrayList<ArrayList<Class>> superClasses;
	
	public static void main(String[] args) {
		list = new ArrayList();
		//list.add(new String("GLIN505"));
		list.add(new Integer(10));
		list.add(new Double(19.5));
		//list.add(new JButton());
		//list.add(new JButton());
		//list.add(new JLabel());
		//list.add(new String("GLIN505"));
		//list.add(new JTextField());
		//list.add(new File("."));
		//list.add(new Integer(10));
		
		getMethods(0);
		
		System.out.println("La classe commune la plus specifique : "+getCommunMostSpecific().getName());
	}
	
	private static void getMethods(int i) {
		Object o = list.get(i);
		
		Method[] methodes = o.getClass().getMethods();
		System.out.println("Classe : "+o.getClass().getName());
		System.out.println("Methodes : ");
		for(Method m : methodes) {
			String m_name = m.getName(); 
			Class m_returnType = m.getReturnType();  
			System.out.print(" "+m_returnType.getName()+" "+m_name + "("); 
			Class[] m_paramTypes = m.getParameterTypes();			
			for (int j=0; j<m_paramTypes.length; j++) 
				System.out.print(m_paramTypes[j].getName());
			System.out.print(")");
			System.out.println(", definie dans : "+m.getDeclaringClass().getName());
		}					
	}
	
	private static void fillSuperClasses() {
		superClasses = new ArrayList<ArrayList<Class>>();		
		for(Object o : list) {
			ArrayList<Class> sc = new ArrayList<Class>();
			Class c = o.getClass().getSuperclass();
			while(c != null) {
				sc.add(c);
				c = c.getSuperclass();
			}
			superClasses.add(sc);
		}
	}
	
	
	
	
	private static Class getCommunMostSpecific() {
		
		fillSuperClasses();
		
		if(superClasses == null) throw new RuntimeException("Probleme d'analyse des super-classes");
		
		Class mostSpecClass = superClasses.get(0).get(0);
				
		ArrayList<Class> first = superClasses.get(0);
		
		for(int i = 0 ; i < first.size() ; i++) {
			int nb = 0; // Le nombre de fois qu'on a trouvéŽ la super-classe dans les diffŽérentes listes
			String className = first.get(i).getName();
			System.out.println("Comparer : "+className);
			for(int j = 1 ; j < superClasses.size(); j++) {
				System.out.println("\t Prochain ArrayList");
				ArrayList<Class> other = superClasses.get(j);
				boolean trouve = false;
				for(int k = 0 ; (k < other.size()) && !trouve; k++) {
					Class cl = other.get(k);
					System.out.println("\t\t Classe : "+cl.getName());
					if(cl.getName().equals(className)) {
						System.out.println("\t\t\t Trouve : "+cl.getName());
						mostSpecClass = cl;						
						trouve = true;		
						nb++;
					}											
				}
			}
			if(nb == superClasses.size() - 1) return mostSpecClass;
		}		
		return mostSpecClass;
	}
}