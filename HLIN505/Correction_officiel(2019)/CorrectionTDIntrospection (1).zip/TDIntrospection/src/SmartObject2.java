import java.lang.reflect.*;

public class SmartObject2 {	
	public String toString() {
		String str="";		
		Class ici = this.getClass();
		Field[] fields = ici.getFields();
		for(Field f : fields) {
			try {
				str += fieldValue(f);			
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}		
		return str;
	}	
	private String fieldValue(Field f) throws Exception {
		System.out.println("\t Depth: "+this.depth);
		if(this.depth == 0) return f.get(this).toString();
		this.depth--;
		String str = "";		
		Class fc = f.getType();
		if(! fc.isPrimitive()) {
			System.out.println("-- Parsing non-primitive Type: "+fc.getName());					
			if(fc.getName().startsWith("java.lang")) // Case of Strings, Integers, ... add their values
				str += f.getName()+":"+String.valueOf(f.get(this))+" - ";
				System.out.print(str);
			Field[] fields = fc.getFields();
			for(Field ff : fields) {
				str += fieldValue(ff);
			}
		}
		else {
			System.out.println("-- Parsing primitive Type: "+fc.getName());
			str += f.getName()+":"+String.valueOf(f.get(this))+" - ";
			System.out.print(str);
		}
		return str;
	}			
	
	private int depth = Integer.MAX_VALUE;
	
	public String toString(int depth) {
		this.depth = depth;
		return this.toString();
	}
}