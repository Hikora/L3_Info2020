import java.lang.reflect.*;
import javax.swing.*;

public class Obj2 extends SmartObject2 {
	public String a;
	public JFrame b;
	public Integer c;
	
	public Obj2(String a, JFrame b) {
		this.a = a;
		this.b = b;
		this.c = new Integer(10);
	}
	
	public static void main(String[] args) {
		JFrame jf = new JFrame();
		jf.setTitle("Title");
		jf.setSize(200,200);
		Obj2 o = new Obj2("Coucou",jf);
		System.out.println(o.toString(3));
	}
}