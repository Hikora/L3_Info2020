
public abstract class PokemonAnnotee { 
	public String nom; 
	private Integer poids; 
	public PokemonAnnotee(String nom, Integer poids) {
		this.nom = nom;
		this.poids = poids; 
	} 
	public abstract Double vitesse(); 
	public Integer getPoids() {
		return poids;
	} 
	public String toString() { 
		return "Je suis le pokémon " + nom + ", mon poids est de " + poids + " kg, ma vitesse est de "+ (double)vitesse() + " km/h";
	}
} 

abstract class PokemonTerreAnnotee extends PokemonAnnotee { 
	private Integer nbPattes; 
	private Double taille; 
	public PokemonTerreAnnotee (String nom, Integer poids, Integer nbPattes, Double taille) {
		super (nom, poids); 
		this.nbPattes = nbPattes; 
		this.taille = taille; 
	} 
	@Todo(kind=Todo.TaskKind.REFACTOR,version="1.0.0",duration=10.5)
	public Double vitesse() {
		return nbPattes * taille * 3;
	} 
	public String toString() {
		return super.toString() + ", j'ai " + nbPattes + " pattes, ma taille est de " +  taille + " m";
	}
}
class PokemonCasanierAnnotee extends PokemonTerreAnnotee { 
	private Integer tele; 
	public PokemonCasanierAnnotee(String nom, Integer poids, Integer nbPattes, Double taille, Integer tele) {
		super(nom,poids,nbPattes,taille); 
		this.tele = tele; 
	} 
	@Todo(kind=Todo.TaskKind.WRITE,version="1.0.1",duration=25.5)
	public String toString() {
		return super.toString()+ ", je regarde la télé " +tele+ " heures par jour";
	}
}
class PokemonSportifAnnotee extends PokemonTerreAnnotee { 	
	private Integer frequence; 
	public PokemonSportifAnnotee(String nom, Integer poids, Integer nbPattes, Double taille, Integer frequence) {
		super(nom,poids,nbPattes,taille); 
		this.frequence = frequence; 
	} 
	public String toString() { 
		return super.toString() + ", ma fréquence cardiaque est de " + frequence + " pulsations à la minute";
	}
}
class PokemonMerAnnotee extends PokemonAnnotee { 
	private Integer nbNageoires; 
	public PokemonMerAnnotee (String nom, Integer poids, Integer nbNageoires) { 
		super (nom, poids); 
	this.nbNageoires = nbNageoires; 
	} 
	public Double vitesse() {
		return getPoids().doubleValue()/25 * nbNageoires;
	} 
	public String toString() {
		return super.toString() + ", j'ai " + nbNageoires + " nageoires";
	}
}
class PokemonCroisiereAnnotee extends PokemonMerAnnotee { 
	public PokemonCroisiereAnnotee (String nom, Integer poids, Integer nbNageoires) {
		super(nom,poids,nbNageoires);
	} 
	public Double vitesse() { 
		return super.vitesse() / 2;
	} 
}
