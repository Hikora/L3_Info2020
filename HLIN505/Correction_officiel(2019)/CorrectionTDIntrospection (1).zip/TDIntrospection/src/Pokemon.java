
public abstract class Pokemon { 
	public String nom; 
	public int poids; 
	public Pokemon() {}
	public Pokemon(String nom, int poids) {
		this.nom = nom;
		this.poids = poids; 
	} 
	public abstract double vitesse(); 
	public int getPoids() {
		return poids;
	} 
	public String toString() { 
		return "Je suis le pokémon " + nom + ", mon poids est de " + poids + " kg, ma vitesse est de "+ (float)vitesse() + " km/h";
	}
} 

abstract class PokemonTerre extends Pokemon { 
	public int nbPattes; 
	public double taille; 
	public PokemonTerre(){}
	public PokemonTerre (String nom, int poids, int nbPattes, double taille) {
		super (nom, poids); 
		this.nbPattes = nbPattes; 
		this.taille = taille; 
	} 
	public double vitesse() {
		return nbPattes * taille * 3;
	} 
	public String toString() {
		return super.toString() + ", j'ai " + nbPattes + " pattes, ma taille est de " +  taille + " m";
	}
}
class PokemonCasanier extends PokemonTerre { 
	public int tele; 
	public PokemonCasanier(){}
	public PokemonCasanier(String nom, int poids, int nbPattes, double taille, int tele) {
		super(nom,poids,nbPattes,taille); 
		this.tele = tele; 
	} 
	public String toString() {
		return super.toString()+ ", je regarde la télé " +tele+ " heures par jour";
	}
}
class PokemonSportif extends PokemonTerre { 	
	public int frequence; 
	public PokemonSportif(){}
	public PokemonSportif(String nom, int poids, int nbPattes, double taille, int frequence) {
		super(nom,poids,nbPattes,taille); 
		this.frequence = frequence; 
	} 
	public String toString() { 
		return super.toString() + ", ma fréquence cardiaque est de " + frequence + " pulsations à la minute";
	}
}
class PokemonMer extends Pokemon { 
	public int nbNageoires; 
	public PokemonMer(){}
	public PokemonMer (String nom, int poids, int nbNageoires) { 
		super (nom, poids); 
	this.nbNageoires = nbNageoires; 
	} 
	public double vitesse() {
		return (double)getPoids()/25 * nbNageoires;
	} 
	public String toString() {
		return super.toString() + ", j'ai " + nbNageoires + " nageoires";
	}
}
class PokemonCroisiere extends PokemonMer { 
	public PokemonCroisiere(){}
	public PokemonCroisiere (String nom, int poids, int nbNageoires) {
		super(nom,poids,nbNageoires);
	} 
	public double vitesse() { 
		return super.vitesse() / 2;
	} 
}
