
import java.lang.reflect.*;
import javax.swing.*;

public class Obj extends SmartObject {
	public String a;
	public JFrame b;
	public Integer c;
	
	public Obj(String a, JFrame b) {
		this.a = a;
		this.b = b;
		this.c = new Integer(10);
	}
	
	public static void main(String[] args) {
		JFrame jf = new JFrame();
		jf.setTitle("Title");
		jf.setSize(200,200);
		Obj o = new Obj("Coucou",jf);
		System.out.println(o.toString());
	}
}