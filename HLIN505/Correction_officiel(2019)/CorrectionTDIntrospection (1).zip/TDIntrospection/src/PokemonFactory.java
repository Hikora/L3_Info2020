
import java.util.*;
import java.lang.reflect.*;

public class PokemonFactory {

	public static Scanner input = new Scanner(System.in);
	
	public static Pokemon newEmptyInstance() throws Exception {
		System.out.print("Entrer le nom de la classe de Pokemon : ");
		String className = input.nextLine();
		Class c = Class.forName(className);		
		Pokemon np = (Pokemon) c.newInstance();		
		return np;
	}
	
	public static Pokemon newInstance() throws Exception {		
		Object np = newEmptyInstance();
		Field[] fields = np.getClass().getFields();
		for(Field f : fields) {
			System.out.print("Entrer la valeur de l'attribut "+f.getName()+" (un "+f.getType().getName()+") : ");
			String val = input.nextLine();
			if(f.getType().getName().equals("int")){
				int a = Integer.parseInt(val);
				f.set(np,a);
			}
			else {
				if(f.getType().getName().equals("double")){
					double x = Double.parseDouble(val);
					f.set(np,x);
				}
				else {
					assert f.getType().getName().endsWith("String") : "Type incorrect pour l'attribut : "+f.getName();
					f.set(np,val);
				}
			}
		}				
		return (Pokemon)np;
	}	
	
	public static Pokemon migrate(Pokemon p, String toClass) throws Exception {
		Class c = Class.forName(toClass);		
		Pokemon np = (Pokemon) c.newInstance();		
		Field[] fields = c.getFields();
		Field[] existingFlds = p.getClass().getFields();
		for(Field f : fields) {
			int pos = fieldPosition(f,existingFlds);
			if(pos != -1) {
				System.out.println("Valeur de l'attribut "+f.getName()+" copiee.");
				f.set(np,existingFlds[pos].get(p));
			}
			else {
				System.out.print("Entrer la valeur de l'attribut "+f.getName()+" (un "+f.getType().getName()+") : ");
				String val = input.nextLine();
				if(f.getType().getName().equals("int")){
					int a = Integer.parseInt(val);
					f.set(np,a);
				}
				else {
					if(f.getType().getName().equals("double")){
						double x = Double.parseDouble(val);
						f.set(np,x);
					}
					else {
						assert f.getType().getName().endsWith("String") : "Type incorrect pour l'attribut : "+f.getName();
						f.set(np,val);
					}
				}
			}
		}
		return np;		
	}
	
	private static int fieldPosition(Field field, Field[] fields) {
		for(int i = 0; i < fields.length ; i++) {
			Field f = fields[i];
			if(f.getName().equals(field.getName())) {
				if(f.getType().getName().equals(field.getType().getName()))
					return i;
			}
		}
		return -1;
	}
	
	public static void main(String[] args) throws Exception {				
		Pokemon p = PokemonFactory.newInstance();
		System.out.println(p);
		System.out.print("Pour migrer, entrer le nom de la nouvelle classe de Pokemon : ");
		String className = input.nextLine();
		p = migrate(p,className);
		System.out.println(p);
	}
	
}